package orm;

public class ORMException extends RuntimeException{

    public  ORMException(String msg){
        super(msg);
    }
}
